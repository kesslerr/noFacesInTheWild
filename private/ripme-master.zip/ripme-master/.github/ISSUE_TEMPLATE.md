<!--
We've moved! If you are not already, please consider opening your issue at the following link:
https://github.com/RipMeApp/ripme/issues/new

If this is a bug, please fill out the information below.
Please include any additional information that would help us fix the bug.
If this is a feature request or other type of issue, provide whatever information you feel is appropriate.
-->

# We've moved to [ripmeapp/ripme](https://github.com/RipMeApp/ripme)!

Please consider opening your issue at https://github.com/RipMeApp/ripme/issues/new instead!

# Issue Details

* Ripme version:
* Java version (output of `java -version`):
* Operating system:
* Exact URL you were trying to rip when the problem occurred:
* Please include any additional information about how to reproduce the problem:

## Expected Behavior

Detail the expected behavior here.

## Actual Behavior

Detail the actual (incorrect) behavior here. You can post log snippets or attach log files to your issue report.
